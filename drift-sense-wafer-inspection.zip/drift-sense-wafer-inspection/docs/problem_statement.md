# Problem Statement – Drift Sense

The project is based on the supplied Applied Materials Drift Sense webinar transcript. The core task is to locate a high-resolution reference pattern within a larger wide-search image and return its X-Y pixel coordinates.

The challenge includes stage/navigation error, scale and small rotation differences, noise, distortion and repetitive patterns. The webinar describes synthetic data generation because real customer images are proprietary.

The development submission should document the Python implementation, dataset/ground truth, method, computation time, evaluation, references and difficult/failure cases.

This document summarizes the supplied webinar and does not replace official hackathon landing-page rules.
