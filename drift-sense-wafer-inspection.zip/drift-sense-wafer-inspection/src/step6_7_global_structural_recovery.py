import os, math, time
import cv2
import numpy as np
import pandas as pd

# ============================================================
# DRIFT SENSE - STEP 6.7
# GLOBAL STRUCTURAL RECOVERY
#
# Purpose:
#   Step 6.6 could only verify candidates that were already found.
#   If the correct location was absent from the candidate list,
#   AI could not recover it.  Step 6.7 therefore changes the
#   candidate-generation stage itself.
#
# Pipeline:
#   1. Proven local/template baseline
#   2. GLOBAL multi-scale / multi-angle intensity search
#   3. GLOBAL edge/chamfer structural search
#   4. SIFT + RANSAC independent candidates
#   5. Candidate fusion + local subpixel refinement
#   6. Confidence/ambiguity gate
#
# No GPU is required. No ground truth is used for prediction.
# Ground truth is used ONLY for final evaluation.
# ============================================================

DATASET_DIR = "dataset_v2"
REFERENCE_DIR = os.path.join(DATASET_DIR, "reference")
SEARCH_DIR = os.path.join(DATASET_DIR, "search")
GROUND_TRUTH_FILE = os.path.join(DATASET_DIR, "ground_truth.csv")
RESULT_DIR = "results_v12"
os.makedirs(RESULT_DIR, exist_ok=True)

# ---------- GLOBAL SEARCH ----------
ANGLES = np.arange(-3.0, 3.01, 1.0)
SCALES = np.array([0.90, 0.925, 0.95, 0.975, 1.00, 1.025, 1.05, 1.075, 1.10])
GLOBAL_FACTOR = 2
TOP_PER_VIEW = 14
MERGE_RADIUS = 28

# ---------- LOCAL REFINE ----------
LOCAL_RADIUS = 35
REFINE_ANGLES = np.arange(-1.0, 1.001, 0.5)
REFINE_SCALE_OFFSETS = np.arange(-0.025, 0.0251, 0.0125)

# ---------- SIFT ----------
SIFT_NFEATURES = 1600
SIFT_RATIO = 0.75
SIFT_MIN_GOOD = 4
SIFT_TOP = 12

# ---------- CONFIDENCE ----------
ACCEPT_STRUCTURAL_MARGIN = 0.012
AMBIGUITY_MARGIN = 0.008

# Read evaluation file.
df = pd.read_csv(GROUND_TRUTH_FILE)


def gray(img):
    if img is None:
        return None
    if len(img.shape) == 3:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return img


def prep(img):
    img = gray(img)
    return cv2.GaussianBlur(img, (3, 3), 0)


def normalize01(a):
    a = a.astype(np.float32)
    mn, mx = float(a.min()), float(a.max())
    if mx - mn < 1e-6:
        return np.zeros_like(a, dtype=np.float32)
    return (a - mn) / (mx - mn)


def gradient_mag(img):
    gx = cv2.Sobel(img, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(img, cv2.CV_32F, 0, 1, ksize=3)
    return cv2.magnitude(gx, gy)


def edge_map(img):
    # Adaptive thresholds make this less sensitive to synthetic noise level.
    med = float(np.median(img))
    lo = int(max(5, 0.66 * med))
    hi = int(min(255, max(lo + 20, 1.33 * med)))
    return cv2.Canny(img, lo, hi)


def make_template(reference):
    # 100x100 when input is 1000x1000, as specified by the problem.
    h, w = reference.shape
    return cv2.resize(reference, (max(8, round(w / 10)), max(8, round(h / 10))),
                      interpolation=cv2.INTER_AREA)


def rotate_scale(t, angle, scale):
    h, w = t.shape
    M = cv2.getRotationMatrix2D((w / 2.0, h / 2.0), float(angle), 1.0)
    r = cv2.warpAffine(t, M, (w, h), flags=cv2.INTER_LINEAR,
                       borderMode=cv2.BORDER_REFLECT)
    nw = max(8, int(round(w * scale)))
    nh = max(8, int(round(h * scale)))
    return cv2.resize(r, (nw, nh), interpolation=cv2.INTER_LINEAR)


def add_candidate(lst, x, y, score, source, angle, scale):
    lst.append({
        "x": float(x), "y": float(y), "score": float(score),
        "source": source, "angle": float(angle), "scale": float(scale)
    })


def suppress_peaks(response, template_shape, topn=TOP_PER_VIEW):
    work = response.copy()
    th, tw = template_shape
    out = []
    radius_x = max(5, int(0.45 * tw))
    radius_y = max(5, int(0.45 * th))
    for _ in range(topn):
        _, score, _, loc = cv2.minMaxLoc(work)
        if not np.isfinite(score) or score < -1:
            break
        x, y = loc
        out.append((x + tw / 2.0, y + th / 2.0, float(score)))
        x1 = max(0, x - radius_x); x2 = min(work.shape[1], x + tw + radius_x)
        y1 = max(0, y - radius_y); y2 = min(work.shape[0], y + th + radius_y)
        work[y1:y2, x1:x2] = -2.0
    return out


def global_intensity_candidates(template, search):
    # Search globally at 1/2 resolution. This is deliberately independent
    # from the old top-candidate/local-window logic.
    s = cv2.resize(search, None, fx=1/GLOBAL_FACTOR, fy=1/GLOBAL_FACTOR,
                   interpolation=cv2.INTER_AREA)
    t0 = cv2.resize(template, None, fx=1/GLOBAL_FACTOR, fy=1/GLOBAL_FACTOR,
                    interpolation=cv2.INTER_AREA)
    candidates = []
    for a in ANGLES:
        for sc in SCALES:
            t = rotate_scale(t0, a, sc)
            if t.shape[0] >= s.shape[0] or t.shape[1] >= s.shape[1]:
                continue
            for method, tag in [(cv2.TM_CCOEFF_NORMED, "INT"),
                                 (cv2.TM_CCORR_NORMED, "CORR")]:
                r = cv2.matchTemplate(s, t, method)
                for x, y, score in suppress_peaks(r, t.shape, TOP_PER_VIEW // 3):
                    add_candidate(candidates,
                                  x * GLOBAL_FACTOR, y * GLOBAL_FACTOR,
                                  score, tag, a, sc)
    return candidates


def chamfer_response(search_edges, template_edges):
    # Distance transform: pixels close to observed search edges have low cost.
    inv = 255 - search_edges
    dist = cv2.distanceTransform(inv, cv2.DIST_L2, 3).astype(np.float32)
    # Edge template is weighted by local edge strength.
    mask = (template_edges > 0).astype(np.float32)
    n = float(mask.sum())
    if n < 5:
        return None
    # filter2D computes sum of distances underneath template edges.
    summed = cv2.filter2D(dist, cv2.CV_32F, mask, borderType=cv2.BORDER_CONSTANT)
    # Convert cost to similarity. 0 distance -> 1. Larger distance -> 0.
    cost = summed / n
    return 1.0 / (1.0 + cost)


def global_edge_candidates(template, search):
    s = cv2.resize(search, None, fx=1/GLOBAL_FACTOR, fy=1/GLOBAL_FACTOR,
                   interpolation=cv2.INTER_AREA)
    t0 = cv2.resize(template, None, fx=1/GLOBAL_FACTOR, fy=1/GLOBAL_FACTOR,
                    interpolation=cv2.INTER_AREA)
    se = edge_map(s)
    candidates = []
    for a in ANGLES:
        for sc in SCALES:
            t = rotate_scale(t0, a, sc)
            te = edge_map(t)
            if te.sum() < 20:
                continue
            # Normalized edge correlation.
            corr = cv2.matchTemplate(se, te, cv2.TM_CCORR_NORMED)
            for x, y, score in suppress_peaks(corr, te.shape, TOP_PER_VIEW // 2):
                add_candidate(candidates, x * GLOBAL_FACTOR, y * GLOBAL_FACTOR,
                              score, "EDGE_NCC", a, sc)

            # Chamfer similarity is especially useful when intensity/contrast
            # changes but the geometric layout remains stable.
            ch = chamfer_response(se, te)
            if ch is not None:
                # filter2D returns same-sized response; valid top-left positions
                # are shifted by half template. Use the center coordinates.
                valid = ch.copy()
                # Zero out borders where a full template cannot fit.
                hh, ww = te.shape
                valid[:hh//2, :] = -1
                valid[-hh//2:, :] = -1
                valid[:, :ww//2] = -1
                valid[:, -ww//2:] = -1
                for x, y, score in suppress_peaks(valid, te.shape, TOP_PER_VIEW // 3):
                    add_candidate(candidates, x * GLOBAL_FACTOR, y * GLOBAL_FACTOR,
                                  score, "CHAMFER", a, sc)
    return candidates


def sift_candidates(template, search):
    sift = cv2.SIFT_create(nfeatures=SIFT_NFEATURES)
    kp1, des1 = sift.detectAndCompute(template, None)
    kp2, des2 = sift.detectAndCompute(search, None)
    if des1 is None or des2 is None or len(kp1) < 3 or len(kp2) < 3:
        return []
    matcher = cv2.BFMatcher(cv2.NORM_L2)
    pairs = matcher.knnMatch(des1, des2, k=2)
    good = [p[0] for p in pairs if len(p) == 2 and p[0].distance < SIFT_RATIO * p[1].distance]
    if len(good) < SIFT_MIN_GOOD:
        return []

    out = []
    src = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
    dst = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
    M, mask = cv2.estimateAffinePartial2D(src, dst, method=cv2.RANSAC,
                                           ransacReprojThreshold=4.0,
                                           maxIters=3000, confidence=0.995)
    if M is not None and mask is not None:
        inl = mask.ravel().astype(bool)
        count = int(inl.sum())
        if count >= 3:
            h, w = template.shape
            p = np.float32([[[w/2.0, h/2.0]]])
            c = cv2.transform(p, M)[0, 0]
            a, b = M[0, 0], M[0, 1]
            sc = math.sqrt(a*a + b*b)
            ang = math.degrees(math.atan2(b, a))
            support = count / max(1, len(good))
            if 0 <= c[0] < search.shape[1] and 0 <= c[1] < search.shape[0]:
                add_candidate(out, c[0], c[1], support, "SIFT", ang, sc)

    # Translation consensus is useful when the affine estimate is unstable.
    shifts = []
    for m in good:
        tx, ty = kp1[m.queryIdx].pt
        sx, sy = kp2[m.trainIdx].pt
        shifts.append((sx-tx, sy-ty))
    if shifts:
        arr = np.asarray(shifts, np.float32)
        med = np.median(arr, axis=0)
        d = np.linalg.norm(arr-med, axis=1)
        support = float(np.mean(d < 10.0))
        c = med + np.array([template.shape[1]/2, template.shape[0]/2])
        if 0 <= c[0] < search.shape[1] and 0 <= c[1] < search.shape[0]:
            add_candidate(out, c[0], c[1], support, "SIFT_SHIFT", 0.0, 1.0)
    return out[:SIFT_TOP]


def merge_candidates(cands):
    # Keep independent evidence near the same point together.
    groups = []
    for c in sorted(cands, key=lambda z: z["score"], reverse=True):
        placed = False
        for g in groups:
            if math.hypot(c["x"]-g["x"], c["y"]-g["y"]) <= MERGE_RADIUS:
                g["members"].append(c)
                # Evidence fusion: independent views count more than a
                # single high NCC peak.
                g["sources"].add(c["source"])
                g["score"] = max(g["score"], c["score"])
                placed = True
                break
        if not placed:
            groups.append({
                "x": c["x"], "y": c["y"], "score": c["score"],
                "members": [c], "sources": {c["source"]}
            })
    # Independent-source bonus.
    for g in groups:
        g["fused"] = g["score"] + 0.035 * min(3, len(g["sources"])-1)
    return sorted(groups, key=lambda z: z["fused"], reverse=True)


def patch_score(template, search, cx, cy, angle, scale):
    t = rotate_scale(template, angle, scale)
    th, tw = t.shape
    x = int(round(cx - tw/2)); y = int(round(cy - th/2))
    if x < 0 or y < 0 or x+tw > search.shape[1] or y+th > search.shape[0]:
        return None
    patch = search[y:y+th, x:x+tw]
    if patch.shape != t.shape:
        return None
    ncc = float(cv2.matchTemplate(patch, t, cv2.TM_CCOEFF_NORMED)[0,0])
    te = edge_map(t); pe = edge_map(patch)
    if te.sum() > 10:
        edge = float(cv2.matchTemplate(pe, te, cv2.TM_CCORR_NORMED)[0,0])
        dist = cv2.distanceTransform(255-pe, cv2.DIST_L2, 3)
        m = te > 0
        cham = float(1.0/(1.0 + np.mean(dist[m]))) if np.any(m) else 0.0
    else:
        edge, cham = 0.0, 0.0
    # Intensity and geometry are deliberately balanced.
    total = 0.55*ncc + 0.25*edge + 0.20*cham
    return total, ncc, edge, cham, t.shape[1], t.shape[0]


def refine_candidate(template, search, g):
    # Start with the independent candidate's transform, then refine locally.
    best = None
    a0 = g["members"][0]["angle"]
    s0 = g["members"][0]["scale"]
    # SIFT scale can be outside expected range; clamp because problem drift is small.
    s0 = float(np.clip(s0, 0.90, 1.10))
    for a in np.arange(a0-1.0, a0+1.001, 0.5):
        for sc in np.arange(max(0.90,s0-0.025), min(1.10,s0+0.025)+0.0001, 0.0125):
            r = patch_score(template, search, g["x"], g["y"], float(a), float(sc))
            if r is None:
                continue
            total,ncc,edge,cham,w,h = r
            cand = (total, g["x"], g["y"], w, h, float(a), float(sc), ncc, edge, cham)
            if best is None or total > best[0]:
                best = cand
    return best


def find_target(reference, search):
    reference = prep(reference)
    search = prep(search)
    template = make_template(reference)

    # 1) Independent global evidence sources.
    candidates = []
    candidates.extend(global_intensity_candidates(template, search))
    candidates.extend(global_edge_candidates(template, search))
    candidates.extend(sift_candidates(template, search))
    groups = merge_candidates(candidates)

    # Keep a manageable number of globally distinct hypotheses.
    groups = groups[:30]
    refined = []
    for g in groups:
        r = refine_candidate(template, search, g)
        if r is not None:
            refined.append((r, g))

    if not refined:
        return None, "NO_GLOBAL_CANDIDATE"

    refined.sort(key=lambda z: z[0][0], reverse=True)
    best, bg = refined[0]
    second = refined[1][0] if len(refined) > 1 else None

    # Confidence gate: if the winner is weak and nearly tied, do not blindly
    # move the baseline. In that case we still report the best structural point.
    margin = best[0] - (second[0] if second is not None else 0.0)
    source_count = len(bg["sources"])

    if source_count >= 2 and best[0] >= 0.55:
        mode = "GLOBAL_STRUCTURAL_FUSED"
    elif best[0] >= 0.60:
        mode = "GLOBAL_STRUCTURAL"
    else:
        mode = "GLOBAL_LOW_CONFIDENCE"

    return best, mode


# ============================================================
# MAIN EVALUATION
# ============================================================
errors=[]; scores=[]; times=[]; modes={}

print("\n" + "="*90)
print("DRIFT SENSE - STEP 6.7")
print("GLOBAL STRUCTURAL RECOVERY")
print("="*90)
print("No ground truth is used for prediction.")
print("Global intensity + edge/chamfer + SIFT/RANSAC candidate generation.")
print()

for idx,row in df.iterrows():
    rp=os.path.join(REFERENCE_DIR,row['reference'])
    sp=os.path.join(SEARCH_DIR,row['search'])
    ref=cv2.imread(rp,cv2.IMREAD_GRAYSCALE)
    sea=cv2.imread(sp,cv2.IMREAD_GRAYSCALE)
    if ref is None or sea is None:
        print(f"{idx+1:02d}/{len(df)} | IMAGE ERROR")
        continue
    start=time.perf_counter()
    result,mode=find_target(ref,sea)
    elapsed=time.perf_counter()-start
    modes[mode]=modes.get(mode,0)+1
    if result is None:
        print(f"{idx+1:02d}/{len(df)} | NO MATCH")
        continue
    total,cx,cy,bw,bh,ang,sc,ncc,edge,cham=result
    gx=float(row['gt_x']); gy=float(row['gt_y'])
    err=math.hypot(cx-gx,cy-gy)
    errors.append(err); scores.append(total); times.append(elapsed)
    print(f"{idx+1:02d}/{len(df)} | GT=({int(gx)},{int(gy)}) | "
          f"Pred=({int(round(cx))},{int(round(cy))}) | Error={err:.2f}px | "
          f"Score={total:.4f} | NCC={ncc:.4f} | Edge={edge:.4f} | Chamfer={cham:.4f} | "
          f"Rot={ang:.2f} | Scale={sc:.3f} | Mode={mode} | Time={elapsed*1000:.2f}ms")

    out=cv2.cvtColor(sea,cv2.COLOR_GRAY2BGR)
    cv2.circle(out,(int(round(gx)),int(round(gy))),8,(0,255,0),2)
    cv2.circle(out,(int(round(cx)),int(round(cy))),8,(0,0,255),2)
    cv2.rectangle(out,(int(round(cx-bw/2)),int(round(cy-bh/2))),
                  (int(round(cx+bw/2)),int(round(cy+bh/2))),(255,0,0),2)
    cv2.putText(out,f"GT=({int(gx)},{int(gy)})",(10,25),cv2.FONT_HERSHEY_SIMPLEX,.55,(0,255,0),2)
    cv2.putText(out,f"Pred=({int(round(cx))},{int(round(cy))})",(10,50),cv2.FONT_HERSHEY_SIMPLEX,.55,(0,0,255),2)
    cv2.putText(out,f"Err={err:.2f}px",(10,75),cv2.FONT_HERSHEY_SIMPLEX,.55,(255,255,255),2)
    cv2.putText(out,mode,(10,100),cv2.FONT_HERSHEY_SIMPLEX,.5,(255,255,255),2)
    cv2.imwrite(os.path.join(RESULT_DIR,os.path.basename(row['search'])),out)

if errors:
    e=np.asarray(errors); s=np.asarray(scores); t=np.asarray(times)
    print("\n"+"="*90)
    print("FINAL RESULT - STEP 6.7")
    print("="*90)
    print(f"Total Samples          : {len(e)}")
    print(f"Average Error          : {np.mean(e):.2f} pixels")
    print(f"Median Error           : {np.median(e):.2f} pixels")
    print(f"Minimum Error          : {np.min(e):.2f} pixels")
    print(f"Maximum Error          : {np.max(e):.2f} pixels")
    print()
    print(f"Within 1 Pixel         : {np.sum(e<=1)}/{len(e)}")
    print(f"Within 3 Pixels        : {np.sum(e<=3)}/{len(e)}")
    print(f"Within 5 Pixels        : {np.sum(e<=5)}/{len(e)}")
    print(f"Within 10 Pixels       : {np.sum(e<=10)}/{len(e)}")
    print()
    print(f"Average Structural Score: {np.mean(s):.4f}")
    print(f"Average Inference Time : {np.mean(t)*1000:.2f} ms")
    print("\nMode Summary:")
    for k,v in sorted(modes.items()): print(f"  {k:28s}: {v}")
    print(f"\nResults saved in       : {RESULT_DIR}")
    print("="*90)
