# Dataset

Recommended structure:
```text
dataset/
├── reference/
├── search/
└── ground_truth.csv
```

Ground truth should record the target X/Y and, where used, transformation parameters. Do not upload proprietary/customer wafer images.
