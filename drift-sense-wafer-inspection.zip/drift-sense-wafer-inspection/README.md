# Drift Sense – AI-Assisted Navigation Error Recovery for Wafer Inspection Tools

Hackathon project for reference-pattern localization in wafer inspection images.

## Goal
Locate a high-resolution reference pattern inside a wide-search image and return accurate X-Y pixel coordinates.

## Current status
This repository contains the current development implementation and documentation. Experimental results are not claimed as final hackathon performance.

## Structure
- `src/` – development code
- `docs/` – problem statement notes
- `dataset/` – dataset instructions
- `results/` – experiment-output instructions
- `SYNOPSIS.md` – hackathon synopsis

## Run
```bash
pip install -r requirements.txt
python -u src/step6_7_global_structural_recovery.py
```

## Evaluation
Localization error: `sqrt((X_pred-X_GT)^2 + (Y_pred-Y_GT)^2)`

Metrics include average/median/max error, accuracy within 1/3/5/10 pixels, match score and inference time.

## Team
Team Name: ____________________
Members: ______________________
College/Institute: _____________
