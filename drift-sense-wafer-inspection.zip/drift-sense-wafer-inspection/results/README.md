# Results

Store experiment outputs here: evaluation CSVs, prediction images, error plots, runtime measurements and difficult/failure cases. Do not present experimental results as final performance until final validation is complete.
